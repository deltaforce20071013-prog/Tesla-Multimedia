document.addEventListener("DOMContentLoaded", () => {
  const pageIds = ["dashboard","vehicle","navigation","media","camera","phone","settings"];
  const pages = Object.fromEntries(pageIds.map(id => [id, document.getElementById(id)]));
  const navButtons = [...document.querySelectorAll(".nav-btn")];
  let currentPage = "dashboard";
  let previousPage = "dashboard";
  let map = null, userMarker = null, selectedMarker = null, pinMode = false;
  let playlist = [], trackIndex = -1, contacts = [];
  const audio = document.getElementById("audioPlayer");
  const $ = id => document.getElementById(id);

  function showPage(name) {
    if (!pages[name]) return;
    if (name !== "callScreen") previousPage = name;
    currentPage = name;
    pageIds.forEach(id => pages[id].hidden = id !== name);
    navButtons.forEach(btn => btn.classList.toggle("active", btn.dataset.page === name));
    if (name === "navigation") setTimeout(initMap, 120);
  }
  navButtons.forEach(btn => btn.addEventListener("click", () => showPage(btn.dataset.page)));
  document.querySelectorAll("[data-open]").forEach(btn => btn.addEventListener("click", () => showPage(btn.dataset.open)));
  document.querySelectorAll("[data-back]").forEach(btn => btn.addEventListener("click", () => showPage("dashboard")));

  function clock(){ $("clock").textContent = new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}); }
  clock(); setInterval(clock, 1000);

  // Vehicle visual rotation demo
  const rotation = $("rotation"), rotatingCar = $("rotatingCar");
  function setAngle(value) {
    const angle = Number(value);
    rotation.value = angle;
    rotatingCar.style.transform = `rotate(${angle}deg)`;
    $("angleLabel").textContent = angle === 0 ? "TOP VIEW · 0°" : `ROTATED VIEW · ${angle}°`;
  }
  rotation.addEventListener("input", e => setAngle(e.target.value));
  document.querySelectorAll("[data-angle]").forEach(btn => btn.addEventListener("click", () => setAngle(btn.dataset.angle)));

  // Map: Leaflet + OpenStreetMap
  function initMap() {
    if (map || !window.L) return;
    map = L.map("liveMap").setView([39.6542, 66.9597], 13);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19, attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    map.on("click", e => {
      if (!pinMode) return;
      pinMode = false;
      setSelectedPlace(e.latlng.lat, e.latlng.lng, "Dropped marker");
    });
    setTimeout(() => map.invalidateSize(), 200);
  }
  function setSelectedPlace(lat, lng, title) {
    if (!map) return;
    if (selectedMarker) map.removeLayer(selectedMarker);
    selectedMarker = L.marker([lat,lng]).addTo(map);
    $("placeName").textContent = title || "Selected location";
    $("placeDetails").textContent = "Selected map point.";
    $("placeCoords").textContent = `Coordinates: ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    map.setView([lat,lng], 16);
  }
  $("locateBtn").addEventListener("click", () => {
    if (!navigator.geolocation) { $("gpsStatus").textContent = "GPS: NOT SUPPORTED"; return; }
    $("gpsStatus").textContent = "GPS: SEARCHING";
    navigator.geolocation.getCurrentPosition(pos => {
      const {latitude:lat, longitude:lng} = pos.coords;
      initMap();
      if (!map) return;
      if (userMarker) map.removeLayer(userMarker);
      userMarker = L.circleMarker([lat,lng], {radius:9,color:"#fff",weight:3,fillColor:"#168cff",fillOpacity:1}).addTo(map).bindPopup("Your location");
      map.setView([lat,lng],16);
      $("gpsStatus").textContent = "GPS: FOUND";
      $("dashCoords").textContent = `${lat.toFixed(3)}, ${lng.toFixed(3)}`;
      setSelectedPlace(lat,lng,"Your location");
    }, err => {
      $("gpsStatus").textContent = "GPS: PERMISSION NEEDED";
      $("placeDetails").textContent = "Joylashuv ruxsatini yoqing va HTTPS orqali oching.";
    }, {enableHighAccuracy:true, timeout:12000});
  });
  $("dropPin").addEventListener("click", () => { pinMode = true; $("placeDetails").textContent = "Metka qo‘yish uchun xaritadagi joyni bosing."; });
  $("searchPlace").addEventListener("click", async () => {
    const q = $("placeSearch").value.trim();
    if (!q) return;
    $("placeDetails").textContent = "Searching…";
    try {
      const url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=" + encodeURIComponent(q);
      const response = await fetch(url);
      const data = await response.json();
      if (!data.length) { $("placeDetails").textContent = "No result found."; return; }
      const p = data[0]; initMap();
      setSelectedPlace(Number(p.lat), Number(p.lon), p.name || p.display_name.split(",")[0]);
      $("placeDetails").textContent = p.display_name;
    } catch(e) { $("placeDetails").textContent = "Search unavailable. Check internet connection."; }
  });
  $("placeSearch").addEventListener("keydown", e => { if(e.key==="Enter") $("searchPlace").click(); });

  // Audio player
  function fmt(s){ if(!Number.isFinite(s)) return "0:00"; return `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`; }
  function syncTrack(){
    const file = playlist[trackIndex];
    const name = file ? file.name.replace(/\.[^.]+$/,"") : "No music selected";
    $("mediaTrack").textContent = name; $("dashTrack").textContent = name;
    $("mediaArtist").textContent = file ? "Local audio file" : "Choose an audio file from your device";
    $("dashArtist").textContent = file ? "Local audio file" : "Choose an audio file";
    [...$("playlist").querySelectorAll(".playlist-item")].forEach((el,i)=>el.classList.toggle("selected",i===trackIndex));
  }
  function renderPlaylist(){
    $("playlist").innerHTML = "";
    if (!playlist.length) $("playlist").innerHTML = '<div class="empty-state">Your playlist is empty</div>';
    playlist.forEach((file,i)=>{
      const b=document.createElement("button"); b.className="playlist-item"; b.textContent=`${i+1}. ${file.name}`;
      b.addEventListener("click",()=>playIndex(i)); $("playlist").appendChild(b);
    });
    syncTrack();
  }
  function playIndex(i){
    if (!playlist.length) return;
    trackIndex=(i+playlist.length)%playlist.length;
    audio.src=URL.createObjectURL(playlist[trackIndex]); audio.play().catch(()=>{});
    syncTrack(); $("playTrack").textContent="Ⅱ"; $("dashPlay").textContent="Ⅱ";
  }
  $("audioFiles").addEventListener("change", e=>{ playlist.push(...Array.from(e.target.files)); renderPlaylist(); if(trackIndex<0 && playlist.length) playIndex(0); e.target.value=""; });
  function toggleAudio(){
    if (!playlist.length) { showPage("media"); $("audioFiles").click(); return; }
    if(audio.paused){ if(!audio.src) playIndex(Math.max(trackIndex,0)); else audio.play(); $("playTrack").textContent="Ⅱ"; $("dashPlay").textContent="Ⅱ"; }
    else {audio.pause();$("playTrack").textContent="▶";$("dashPlay").textContent="▶";}
  }
  $("playTrack").addEventListener("click",toggleAudio); $("dashPlay").addEventListener("click",toggleAudio);
  $("prevTrack").addEventListener("click",()=>playIndex(trackIndex-1)); $("dashPrev").addEventListener("click",()=>playIndex(trackIndex-1));
  $("nextTrack").addEventListener("click",()=>playIndex(trackIndex+1)); $("dashNext").addEventListener("click",()=>playIndex(trackIndex+1));
  audio.addEventListener("timeupdate",()=>{
    $("currentTime").textContent=fmt(audio.currentTime); $("duration").textContent=fmt(audio.duration);
    $("seekBar").value=audio.duration ? audio.currentTime/audio.duration*100 : 0;
    $("dashProgress").style.width=$("seekBar").value+"%";
  });
  $("seekBar").addEventListener("input",()=>{if(audio.duration) audio.currentTime=audio.duration*Number($("seekBar").value)/100;});
  $("volume").addEventListener("input",e=>audio.volume=Number(e.target.value));
  audio.addEventListener("ended",()=>playIndex(trackIndex+1));

  // Camera demonstration modes
  document.querySelectorAll("[data-camera]").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll("[data-camera]").forEach(b=>b.classList.remove("selected"));
    btn.classList.add("selected");
    const mode=btn.dataset.camera;
    $("cameraPreview").textContent=mode==="360"?"360° SURROUND DEMO":mode.toUpperCase()+" CAMERA DEMO";
  }));

  // Contacts and dial pad (local demo only)
  function renderContacts(){
    $("contactList").innerHTML="";
    contacts.forEach(c=>{
      const b=document.createElement("button"); b.className="contact-item"; b.textContent=`${c.name} · ${c.number}`;
      b.addEventListener("click",()=>{$("dialNumber").value=c.number;}); $("contactList").appendChild(b);
    });
  }
  $("addContact").addEventListener("click",()=>{
    const name=$("contactName").value.trim(), number=$("contactNumber").value.trim();
    if(!name||!number) return;
    contacts.push({name,number}); $("contactName").value=""; $("contactNumber").value=""; renderContacts();
  });
  document.querySelectorAll("[data-digit]").forEach(btn=>btn.addEventListener("click",()=>{$("dialNumber").value += btn.dataset.digit;}));
  $("deleteDigit").addEventListener("click",()=>{$("dialNumber").value=$("dialNumber").value.slice(0,-1);});
  function showCall(status,name,number){
    $("callStatus").textContent=status; $("callerName").textContent=name; $("callerNumber").textContent=number||"Unknown number";
    $("callScreen").hidden=false;
    pages[currentPage].hidden=true;
  }
  function hideCall(){ $("callScreen").hidden=true; showPage("phone"); }
  $("callBtn").addEventListener("click",()=>{const n=$("dialNumber").value.trim();if(n)showCall("CALLING…",n,n);});
  $("incomingDemo").addEventListener("click",()=>showCall("INCOMING CALL", "Demo caller", "+998 90 000 00 00"));
  $("acceptCall").addEventListener("click",()=>{$("callStatus").textContent="CALL CONNECTED · DEMO";});
  $("endCall").addEventListener("click",hideCall);

  // Settings
  $("accentColor").addEventListener("input",e=>document.documentElement.style.setProperty("--accent",e.target.value));
  $("themeSelect").addEventListener("change",e=>document.body.classList.toggle("light",e.target.value==="light"));
  const translations={
    uz:["Vehicle","Map","Media","Camera","Phone","Settings"],
    en:["Vehicle","Map","Media","Camera","Phone","Settings"],
    ru:["Авто","Карта","Медиа","Камера","Телефон","Настройки"],
    ko:["차량","지도","미디어","카메라","전화","설정"]
  };
  $("languageSelect").addEventListener("change",e=>{
    const labels=translations[e.target.value];
    navButtons.forEach((b,i)=>b.querySelector("small").textContent=labels[i]);
  });
  $("resetSettings").addEventListener("click",()=>{
    document.documentElement.style.setProperty("--accent","#168cff");
    $("accentColor").value="#168cff"; $("themeSelect").value="dark"; document.body.classList.remove("light");
    $("languageSelect").value="uz"; navButtons.forEach((b,i)=>b.querySelector("small").textContent=translations.uz[i]);
  });

  showPage("dashboard");
});